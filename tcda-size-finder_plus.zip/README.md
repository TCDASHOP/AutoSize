# TCDA Size Finder (GitHub Pages)

- Dark UI (black background / white text)
- JP/EN toggle
- cm/inch toggle
- Size chart modal + **How to measure** mini guide (chest / foot length)
- Result actions:
  - Copy result
  - Go to product page
  - Open size chart
- Input validation (min/max) + notes to reduce returns

## Edit product page URLs
Open `app.js` and find `productUrl` inside the `DATA` object to set each item’s URL.

## Deploy
Upload all files to the repository root, then enable GitHub Pages:
Settings → Pages → Deploy from a branch → main / (root)
