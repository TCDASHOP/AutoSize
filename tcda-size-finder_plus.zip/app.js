// TCDA Size Finder (GitHub Pages) - all client-side (no server)
'use strict';

/** Embedded size charts (from your CSV files) */
const DATA = {"womens_tee": {"type": "top", "labels": {"ja": "Women's Crew Neck T-Shirt", "en": "Women's Crew Neck T-Shirt"}, "productUrl": "https://www.tcda.shop/", "cm": [{"size": "XS", "widthHalfCm": 40.0, "lengthCm": 59.0, "sleeveCm": 18.0}, {"size": "S", "widthHalfCm": 42.0, "lengthCm": 60.0, "sleeveCm": 19.0}, {"size": "M", "widthHalfCm": 44.0, "lengthCm": 61.0, "sleeveCm": 20.0}, {"size": "L", "widthHalfCm": 48.0, "lengthCm": 64.0, "sleeveCm": 21.0}, {"size": "XL", "widthHalfCm": 52.0, "lengthCm": 67.0, "sleeveCm": 22.0}, {"size": "2XL", "widthHalfCm": 56.0, "lengthCm": 70.0, "sleeveCm": 23.0}], "inch": [{"Size": "XS", "height": "15 ¾", "length": "23 ¼", "height of a sleeve": "7 ⅛"}, {"Size": "S", "height": "16 ½", "length": "23 ⅝", "height of a sleeve": "7 ½"}, {"Size": "M", "height": "17 ⅜", "length": "24", "height of a sleeve": "7 ⅞"}, {"Size": "L", "height": "18 ⅞", "length": "25 ¼", "height of a sleeve": "8 ¼"}, {"Size": "XL", "height": "20 ½", "length": "26 ⅜", "height of a sleeve": "8 ⅝"}, {"Size": "2XL", "height": "22", "length": "27 ½", "height of a sleeve": "9"}]}, "mens_tee": {"type": "top", "labels": {"ja": "Men's Crew Neck T-Shirt", "en": "Men's Crew Neck T-Shirt"}, "productUrl": "https://www.tcda.shop/", "cm": [{"size": "XS", "widthHalfCm": 39.0, "lengthCm": 71.0, "sleeveCm": 22.0}, {"size": "S", "widthHalfCm": 43.0, "lengthCm": 73.0, "sleeveCm": 23.0}, {"size": "M", "widthHalfCm": 47.0, "lengthCm": 75.0, "sleeveCm": 24.0}, {"size": "L", "widthHalfCm": 53.0, "lengthCm": 77.0, "sleeveCm": 25.0}, {"size": "XL", "widthHalfCm": 59.0, "lengthCm": 79.0, "sleeveCm": 26.0}, {"size": "2XL", "widthHalfCm": 65.0, "lengthCm": 81.0, "sleeveCm": 27.0}], "inch": [{"Size": "XS", "height": "15 ⅜", "length": "28", "height of a sleeve": "8 ⅝"}, {"Size": "S", "height": "16 ⅞", "length": "28 ¾", "height of a sleeve": "9"}, {"Size": "M", "height": "18 ½", "length": "29 ½", "height of a sleeve": "9 ½"}, {"Size": "L", "height": "20 ⅞", "length": "30 ¼", "height of a sleeve": "9 ⅞"}, {"Size": "XL", "height": "23 ¼", "length": "31 ⅛", "height of a sleeve": "10 ¼"}, {"Size": "2XL", "height": "25 ⅝", "length": "31 ⅞", "height of a sleeve": "10 ⅝"}]}, "hoodie": {"type": "top", "labels": {"ja": "Recycled Unisex Hoodie", "en": "Recycled Unisex Hoodie"}, "productUrl": "https://www.tcda.shop/", "cm": [{"size": "2XS", "widthHalfCm": 48.0, "lengthCm": 66.5, "sleeveCm": 56.5}, {"size": "XS", "widthHalfCm": 50.0, "lengthCm": 66.5, "sleeveCm": 56.5}, {"size": "S", "widthHalfCm": 52.0, "lengthCm": 68.0, "sleeveCm": 57.5}, {"size": "M", "widthHalfCm": 54.0, "lengthCm": 69.5, "sleeveCm": 58.5}, {"size": "L", "widthHalfCm": 58.0, "lengthCm": 71.0, "sleeveCm": 60.0}, {"size": "XL", "widthHalfCm": 62.0, "lengthCm": 72.5, "sleeveCm": 61.5}, {"size": "2XL", "widthHalfCm": 66.0, "lengthCm": 74.0, "sleeveCm": 63.0}, {"size": "3XL", "widthHalfCm": 70.0, "lengthCm": 75.5, "sleeveCm": 64.5}, {"size": "4XL", "widthHalfCm": 74.0, "lengthCm": 78.5, "sleeveCm": 65.5}, {"size": "5XL", "widthHalfCm": 78.0, "lengthCm": 81.5, "sleeveCm": 66.5}, {"size": "6XL", "widthHalfCm": 82.0, "lengthCm": 84.5, "sleeveCm": 67.5}], "inch": [{"𝐬𝐢𝐳𝐞": "2XS", "1/2 chest width": "18 ⅞", "Length": "26 ⅛", "Sleeve length": "22 ¼"}, {"𝐬𝐢𝐳𝐞": "XS", "1/2 chest width": "19 ¾", "Length": "26 ¼", "Sleeve length": "22 ¼"}, {"𝐬𝐢𝐳𝐞": "S", "1/2 chest width": "20 ½", "Length": "26 ¾", "Sleeve length": "22 ⅝"}, {"𝐬𝐢𝐳𝐞": "M", "1/2 chest width": "21 ¼", "Length": "27 ⅜", "Sleeve length": "23"}, {"𝐬𝐢𝐳𝐞": "L", "1/2 chest width": "22 ⅞", "Length": "28", "Sleeve length": "23 ⅝"}, {"𝐬𝐢𝐳𝐞": "XL", "1/2 chest width": "24 ⅜", "Length": "28 ½", "Sleeve length": "24 ¼"}, {"𝐬𝐢𝐳𝐞": "2XL", "1/2 chest width": "26", "Length": "29 ⅛", "Sleeve length": "24 ¾"}, {"𝐬𝐢𝐳𝐞": "3XL", "1/2 chest width": "27 ½", "Length": "29 ¾", "Sleeve length": "25 ⅜"}, {"𝐬𝐢𝐳𝐞": "4XL", "1/2 chest width": "29 ⅛", "Length": "30 ⅞", "Sleeve length": "25 ¾"}, {"𝐬𝐢𝐳𝐞": "5XL", "1/2 chest width": "30 ¾", "Length": "32 ⅛", "Sleeve length": "26 ⅛"}, {"𝐬𝐢𝐳𝐞": "6XL", "1/2 chest width": "32 ¼", "Length": "33 ¼", "Sleeve length": "26 ⅝"}]}, "ziphoodie": {"type": "top", "labels": {"ja": "Recycled Unisex Zip Hoodie", "en": "Recycled Unisex Zip Hoodie"}, "productUrl": "https://www.tcda.shop/", "cm": [{"size": "2XS", "widthHalfCm": 48.0, "lengthCm": 65.0, "sleeveCm": 55.5}, {"size": "XS", "widthHalfCm": 50.0, "lengthCm": 65.0, "sleeveCm": 55.5}, {"size": "S", "widthHalfCm": 52.0, "lengthCm": 68.0, "sleeveCm": 57.0}, {"size": "M", "widthHalfCm": 54.0, "lengthCm": 68.0, "sleeveCm": 58.5}, {"size": "L", "widthHalfCm": 58.0, "lengthCm": 71.0, "sleeveCm": 60.0}, {"size": "XL", "widthHalfCm": 62.0, "lengthCm": 71.0, "sleeveCm": 61.5}, {"size": "2XL", "widthHalfCm": 66.0, "lengthCm": 74.0, "sleeveCm": 63.0}, {"size": "3XL", "widthHalfCm": 70.0, "lengthCm": 74.0, "sleeveCm": 64.5}, {"size": "4XL", "widthHalfCm": 74.0, "lengthCm": 78.0, "sleeveCm": 65.0}, {"size": "5XL", "widthHalfCm": 78.0, "lengthCm": 78.0, "sleeveCm": 65.5}, {"size": "6XL", "widthHalfCm": 82.0, "lengthCm": 78.0, "sleeveCm": 66.0}], "inch": [{"𝐬𝐢𝐳𝐞": "2XS", "1/2 chest width": "18 ⅞", "Length": "25 ⅝", "Sleeve length": "21 ⅞"}, {"𝐬𝐢𝐳𝐞": "XS", "1/2 chest width": "19 ¾", "Length": "25 ⅝", "Sleeve length": "21 ⅞"}, {"𝐬𝐢𝐳𝐞": "S", "1/2 chest width": "20 ½", "Length": "26 ¾", "Sleeve length": "22 ½"}, {"𝐬𝐢𝐳𝐞": "M", "1/2 chest width": "21 ¼", "Length": "26 ¾", "Sleeve length": "23"}, {"𝐬𝐢𝐳𝐞": "L", "1/2 chest width": "22 ⅞", "Length": "28", "Sleeve length": "23 ⅝"}, {"𝐬𝐢𝐳𝐞": "XL", "1/2 chest width": "24 ⅜", "Length": "28", "Sleeve length": "24 ¼"}, {"𝐬𝐢𝐳𝐞": "2XL", "1/2 chest width": "26", "Length": "29 ⅛", "Sleeve length": "24 ¾"}, {"𝐬𝐢𝐳𝐞": "3XL", "1/2 chest width": "27 ½", "Length": "29 ⅛", "Sleeve length": "25 ⅜"}, {"𝐬𝐢𝐳𝐞": "4XL", "1/2 chest width": "29 ⅛", "Length": "30 ¾", "Sleeve length": "25 ⅝"}, {"𝐬𝐢𝐳𝐞": "5XL", "1/2 chest width": "30 ¾", "Length": "30 ¾", "Sleeve length": "25 ¾"}, {"𝐬𝐢𝐳𝐞": "6XL", "1/2 chest width": "32 ¼", "Length": "30 ¾", "Sleeve length": "26"}]}, "mens_slipon": {"type": "shoe", "labels": {"ja": "Men's Slip-On Canvas Shoes", "en": "Men's Slip-On Canvas Shoes"}, "productUrl": "https://www.tcda.shop/", "cm": [{"sizeJP": "23", "footLengthCm": 23.2, "outsoleLengthCm": 26.2}, {"sizeJP": "23.5", "footLengthCm": 23.5, "outsoleLengthCm": 26.2}, {"sizeJP": "24", "footLengthCm": 24.0, "outsoleLengthCm": 27.0}, {"sizeJP": "24.5", "footLengthCm": 24.5, "outsoleLengthCm": 27.0}, {"sizeJP": "25", "footLengthCm": 24.8, "outsoleLengthCm": 27.3}, {"sizeJP": "25.5", "footLengthCm": 25.4, "outsoleLengthCm": 28.3}, {"sizeJP": "26", "footLengthCm": 25.7, "outsoleLengthCm": 28.3}, {"sizeJP": "26.5", "footLengthCm": 26.0, "outsoleLengthCm": 29.0}, {"sizeJP": "27", "footLengthCm": 26.7, "outsoleLengthCm": 29.5}, {"sizeJP": "27.5", "footLengthCm": 27.0, "outsoleLengthCm": 29.5}, {"sizeJP": "28", "footLengthCm": 27.3, "outsoleLengthCm": 30.5}], "inch": [{"US": "5", "UK": "4", "EU": "37.5", "leg length": "9 ⅛", "outsole length": "10 1/4"}, {"US": "5.5", "UK": "4.5", "EU": "38", "leg length": "91/4", "outsole length": "10 1/4"}, {"US": "6", "UK": "5", "EU": "38.5", "leg length": "91/2", "outsole length": "10⅝"}, {"US": "6.5", "UK": "5.5", "EU": "39", "leg length": "9 ⅝", "outsole length": "10⅝"}, {"US": "7", "UK": "6", "EU": "40", "leg length": "9 ¾", "outsole length": "10 3/4"}, {"US": "7.5", "UK": "6.5", "EU": "40.5", "leg length": "10", "outsole length": "11⅛"}, {"US": "8", "UK": "7", "EU": "41", "leg length": "10⅛", "outsole length": "11⅛"}, {"US": "8.5", "UK": "7.5", "EU": "42", "leg length": "10 1/4", "outsole length": "11 ⅜"}, {"US": "9", "UK": "8", "EU": "42.5", "leg length": "10 1/2", "outsole length": "11 ⅝"}, {"US": "9.5", "UK": "8.5", "EU": "43", "leg length": "10⅝", "outsole length": "11⅝"}, {"US": "10", "UK": "9", "EU": "44", "leg length": "10 3/4", "outsole length": "12"}]}};

let unit = 'cm';  // 'cm' | 'inch'
let lang = 'ja';  // 'ja' | 'en'
let activeItemId = 'womens_tee';
let modalTab = 'chart'; // 'chart' | 'howto'

const $ = (id) => document.getElementById(id);

function cmToInch(cm){ return cm / 2.54; }
function inchToCm(inch){ return inch * 2.54; }
function r1(n){ return Math.round(n * 10) / 10; }
function t(ja,en){ return (lang === 'ja') ? ja : en; }

function makeEl(tag, attrs={}, children=[]){
  const el = document.createElement(tag);
  for(const [k,v] of Object.entries(attrs)){
    if(k === 'class') el.className = v;
    else if(k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else if(v !== null && v !== undefined) el.setAttribute(k, String(v));
  }
  for(const ch of children){
    if(ch === null || ch === undefined) continue;
    if(typeof ch === 'string') el.appendChild(document.createTextNode(ch));
    else el.appendChild(ch);
  }
  return el;
}

function currentItem(){ return DATA[activeItemId]; }
function itemLabel(id){ return (DATA[id].labels && (DATA[id].labels[lang] || DATA[id].labels.en)) || id; }
function itemIdIsTee(id){ return id === 'womens_tee' || id === 'mens_tee'; }

// ---------------- UI: Tabs ----------------
function renderTabs(){
  const tabs = $('tabs');
  tabs.innerHTML = '';
  Object.keys(DATA).forEach((id) => {
    const btn = makeEl('button', {
      class:'tab', type:'button', role:'tab',
      'aria-selected': id === activeItemId ? 'true' : 'false',
      onclick: () => { activeItemId = id; renderAll(); }
    }, [itemLabel(id)]);
    tabs.appendChild(btn);
  });
}

// ---------------- UI: Form ----------------
function renderForm(){
  const grid = $('formGrid');
  grid.innerHTML = '';
  const item = currentItem();

  if(item.type === 'top'){
    grid.appendChild(makeEl('label', {class:'field'}, [
      makeEl('span', {id:'labelChest'}, [t('胸囲（ヌード）','Body chest (nude)')]),
      makeEl('input', {id:'chest', type:'number', inputmode:'decimal', placeholder:t('例：88','e.g., 35'), autocomplete:'off'}),
      makeEl('small', {class:'muted', id:'unitHint'}, [t('単位：' + unit, 'Unit: ' + unit)])
    ]));

    grid.appendChild(makeEl('label', {class:'field'}, [
      makeEl('span', {id:'labelHeight'}, [t('身長（任意）','Height (optional)')]),
      makeEl('input', {id:'height', type:'number', inputmode:'decimal', placeholder:t('例：160','e.g., 63'), autocomplete:'off'}),
      makeEl('small', {class:'muted', id:'heightHint'}, [t('単位：' + unit, 'Unit: ' + unit)])
    ]));

    const fit = makeEl('select', {id:'fit'}, [
      makeEl('option', {value:'8'}, [t('ジャスト（ゆとり+8cm）','Snug (+8cm ease)')]),
      makeEl('option', {value:'12', selected:'selected'}, [t('ふつう（ゆとり+12cm）','Regular (+12cm ease)')]),
      makeEl('option', {value:'16'}, [t('ゆったり（ゆとり+16cm）','Relaxed (+16cm ease)')]),
      makeEl('option', {value:'20'}, [t('オーバーサイズ（ゆとり+20cm）','Oversized (+20cm ease)')]),
    ]);

    grid.appendChild(makeEl('label', {class:'field'}, [
      makeEl('span', {id:'labelFit'}, [t('フィット感','Fit')]),
      fit
    ]));
  } else {
    grid.appendChild(makeEl('label', {class:'field'}, [
      makeEl('span', {id:'labelFoot'}, [t('足の長さ（実寸）','Foot length')]),
      makeEl('input', {id:'foot', type:'number', inputmode:'decimal', placeholder:t('例：26.5','e.g., 10.4'), autocomplete:'off'}),
      makeEl('small', {class:'muted', id:'unitHint'}, [t('単位：' + unit, 'Unit: ' + unit)])
    ]));
  }
}

// ---------------- Validation ----------------
function clearFieldErrors(){
  ['chest','height','foot'].forEach((id) => {
    const el = $(id);
    if(el) el.classList.remove('error');
  });
}
function markError(id){
  const el = $(id);
  if(el) el.classList.add('error');
}

function validateTopInputs(chestRaw, heightRaw){
  const chestCm = (unit === 'cm') ? chestRaw : inchToCm(chestRaw);
  const heightCm = (heightRaw == null || Number.isNaN(heightRaw)) ? null : ((unit === 'cm') ? heightRaw : inchToCm(heightRaw));

  if(!Number.isFinite(chestCm) || chestCm < 60 || chestCm > 160){
    markError('chest');
    return {ok:false, message:t('胸囲は 60〜160cm の範囲で入力してください。','Please enter chest between 60 and 160 cm.')};
  }
  if(heightCm !== null && (heightCm < 130 || heightCm > 210)){
    markError('height');
    return {ok:false, message:t('身長は 130〜210cm の範囲で入力してください（任意）。','Please enter height between 130 and 210 cm (optional).')};
  }
  return {ok:true, chestCm, heightCm};
}

function validateShoeInputs(footRaw){
  const footCm = (unit === 'cm') ? footRaw : inchToCm(footRaw);
  if(!Number.isFinite(footCm) || footCm < 20 || footCm > 32){
    markError('foot');
    return {ok:false, message:t('足の長さは 20〜32cm の範囲で入力してください。','Please enter foot length between 20 and 32 cm.')};
  }
  return {ok:true, footCm};
}

// ---------------- Recommendation ----------------
function pickTopSize(chestCm, easeCm, itemId){
  const rows = DATA[itemId].cm;
  const target = chestCm + easeCm;

  let best = null;
  for(const row of rows){
    const garmentChest = (row.widthHalfCm || 0) * 2;
    if(garmentChest >= target){
      const diff = garmentChest - target;
      if(!best || diff < best.diff){
        best = {size: row.size, garmentChest, target, diff, row};
      }
    }
  }

  if(!best){
    const last = rows[rows.length - 1];
    best = {size:last.size, garmentChest:(last.widthHalfCm || 0) * 2, target, diff:((last.widthHalfCm||0)*2)-target, overflow:true, row:last};
  }
  return best;
}

// Parse strings like "10 1/4", "10⅝", "9 ⅛", "91/4"
function parseInchString(s){
  if(s == null) return null;
  let str = String(s).trim();
  if(!str) return null;

  const map = {'⅛':'1/8','¼':'1/4','½':'1/2','¾':'3/4','⅜':'3/8','⅝':'5/8','⅞':'7/8','⅓':'1/3','⅔':'2/3'};
  for(const [k,v] of Object.entries(map)) str = str.split(k).join(' ' + v);

  // fix 10 5/8 already ok; fix 10⅝ => "10 5/8"
  str = str.replace(/(\d)(\s*\d\/\d)/g, '$1 $2');
  // fix 91/4 => 9 1/4
  str = str.replace(/^(\d)(\d\/\d)$/, '$1 $2');

  const parts = str.split(/\s+/);
  let whole = 0, frac = 0;
  for(const p of parts){
    if(/^\d+(\.\d+)?$/.test(p)) whole = parseFloat(p);
    else if(/^\d+\/\d+$/.test(p)){
      const [a,b] = p.split('/').map(Number);
      if(b) frac += a / b;
    }
  }
  const val = whole + frac;
  return Number.isFinite(val) ? val : null;
}

function pickShoeSize(footCm, itemId){
  if(unit === 'cm'){
    const rows = DATA[itemId].cm;
    let best = null;
    for(const row of rows){
      if((row.footLengthCm || 0) >= footCm){ best = row; break; }
    }
    if(!best) best = rows[rows.length - 1];
    const overflow = (best.footLengthCm || 0) < footCm;
    return {mode:'cm', row:best, overflow};
  } else {
    const rows = DATA[itemId].inch;
    let best = null;
    for(const r of rows){
      const lenIn = parseInchString(r['leg length']);
      const lenCm = (lenIn == null) ? null : inchToCm(lenIn);
      if(lenCm != null && lenCm >= footCm){ best = r; break; }
    }
    if(!best) best = rows[rows.length - 1];
    const bestIn = parseInchString(best['leg length']) || 0;
    const overflow = inchToCm(bestIn) < footCm;
    return {mode:'inch', row:best, overflow};
  }
}

function hemPositionJa(heightCm, garmentLengthCm){
  const hip = heightCm * 0.55;
  if(garmentLengthCm < hip - 6) return 'ヒップより上あたり（目安）';
  if(garmentLengthCm < hip + 6) return 'ヒップ付近（目安）';
  if(garmentLengthCm < hip + 16) return 'ヒップが隠れるくらい（目安）';
  return 'ヒップより下（ロング寄り／目安）';
}
function hemPositionEn(heightCm, garmentLengthCm){
  const hip = heightCm * 0.55;
  if(garmentLengthCm < hip - 6) return 'Above the hip (approx.)';
  if(garmentLengthCm < hip + 6) return 'Around the hip (approx.)';
  if(garmentLengthCm < hip + 16) return 'Covers the hip (approx.)';
  return 'Below the hip / longer (approx.)';
}

// ---------------- Modal ----------------
function openModal(tab){
  modalTab = tab || 'chart';
  $('modal').hidden = false;
  document.body.style.overflow = 'hidden';
  renderModal();
}
function closeModal(){
  $('modal').hidden = true;
  document.body.style.overflow = '';
}

function renderModal(){
  const wrap = $('tableWrap');
  wrap.innerHTML = '';

  const tabbar = makeEl('div', {class:'modalTabs'}, [
    makeEl('button', {class:'modalTab', type:'button', 'aria-selected': modalTab==='chart' ? 'true':'false', onclick:()=>{ modalTab='chart'; renderModal(); }}, [t('サイズ表','Size chart')]),
    makeEl('button', {class:'modalTab', type:'button', 'aria-selected': modalTab==='howto' ? 'true':'false', onclick:()=>{ modalTab='howto'; renderModal(); }}, [t('測り方','How to measure')]),
  ]);
  wrap.appendChild(tabbar);

  if(modalTab === 'chart'){
    $('modalTitle').textContent = t('サイズ表','Size chart');
    $('modalHint').textContent  = t('横スクロールできます（スマホOK）。','Horizontal scroll available (mobile OK).');
    wrap.appendChild(renderChartTable());
  } else {
    $('modalTitle').textContent = t('測り方','How to measure');
    $('modalHint').textContent  = t('入力値の精度が上がるほど、推奨も当たりやすくなります。','More accurate measurements → better recommendations.');
    wrap.appendChild(renderHowTo());
  }
}

function renderChartTable(){
  const item = currentItem();
  let columns = [];
  let rows = [];

  if(item.type === 'top'){
    if(unit === 'cm'){
      columns = (lang === 'ja') ? ['サイズ','身幅（平置き）','着丈','袖丈'] : ['Size','Chest (flat)','Length','Sleeve'];
      rows = item.cm.map(r => ({c0:r.size, c1:(r.widthHalfCm ?? ''), c2:(r.lengthCm ?? ''), c3:(r.sleeveCm ?? '')}));
    } else {
      const inchRows = item.inch;
      columns = ['Size','Chest (flat)','Length','Sleeve'];
      if(itemIdIsTee(activeItemId)){
        rows = inchRows.map(r => ({c0:r['Size'], c1:r['height'], c2:r['length'], c3:r['height of a sleeve']}));
      } else {
        rows = inchRows.map(r => ({c0:r['𝐬𝐢𝐳𝐞'], c1:r['1/2 chest width'], c2:r['Length'], c3:r['Sleeve length']}));
      }
    }
  } else {
    if(unit === 'cm'){
      columns = (lang === 'ja') ? ['サイズ（JP）','足の長さ','アウトソール'] : ['Size (JP)','Foot length','Outsole'];
      rows = item.cm.map(r => ({c0:r.sizeJP, c1:(r.footLengthCm ?? ''), c2:(r.outsoleLengthCm ?? '')}));
    } else {
      columns = ['US','UK','EU','Foot length','Outsole'];
      rows = item.inch.map(r => ({c0:r['US'], c1:r['UK'], c2:r['EU'], c3:r['leg length'], c4:r['outsole length']}));
    }
  }

  const table = makeEl('table', {}, [
    makeEl('thead', {}, [ makeEl('tr', {}, columns.map(h => makeEl('th', {}, [h]))) ]),
    makeEl('tbody', {}, rows.map(r => {
      const keys = Object.keys(r).sort();
      return makeEl('tr', {}, keys.map(k => makeEl('td', {}, [String(r[k] ?? '')])));
    }))
  ]);

  return makeEl('div', {class:'tableWrapInner'}, [table]);
}

function renderHowTo(){
  const box = makeEl('div', {class:'howtoWrap'}, []);
  // Always show both mini guides as requested
  box.appendChild(howtoCardChest());
  box.appendChild(howtoCardFoot());
  return box;
}

function howtoCardChest(){
  const steps = (lang === 'ja') ? [
    '薄手の服、または下着の上からメジャーを水平に回します。',
    '脇の下の少し下（胸の一番高い位置）を通します。',
    '息を止めず、きつく締めすぎない（指1本入る程度）。',
    '値をそのまま入力（cm推奨）。'
  ] : [
    'Measure over thin clothing or underwear. Keep the tape level.',
    'Measure around the fullest part of the chest (just under the armpits).',
    "Don't hold your breath. Don't pull too tight (about one finger space).",
    'Enter the number (cm recommended).'
  ];

  return makeEl('div', {class:'howtoCard'}, [
    makeEl('div', {class:'howtoTitle'}, [t('胸囲（ヌード）の測り方','How to measure body chest')]),
    makeEl('div', {class:'howtoGrid'}, [
      makeEl('div', {class:'howtoSvg'}, [chestSvg()]),
      makeEl('ol', {class:'howtoList'}, steps.map(s => makeEl('li', {}, [s])))
    ])
  ]);
}

function howtoCardFoot(){
  const steps = (lang === 'ja') ? [
    '紙を床に置き、かかとを壁につけて立ちます。',
    '一番長い指先の位置に印を付けます。',
    '壁〜印までを定規で測ります（左右とも）。',
    '長い方の数値を入力します。'
  ] : [
    'Place paper on the floor and stand with heel against a wall.',
    'Mark the tip of your longest toe.',
    'Measure from the wall to the mark (both feet).',
    'Use the longer measurement.'
  ];

  return makeEl('div', {class:'howtoCard'}, [
    makeEl('div', {class:'howtoTitle'}, [t('足の長さ（実寸）の測り方','How to measure foot length')]),
    makeEl('div', {class:'howtoGrid'}, [
      makeEl('div', {class:'howtoSvg'}, [footSvg()]),
      makeEl('ol', {class:'howtoList'}, steps.map(s => makeEl('li', {}, [s])))
    ])
  ]);
}

function chestSvg(){
  const svg = document.createElementNS('http://www.w3.org/2000/svg','svg');
  svg.setAttribute('viewBox','0 0 240 160');
  svg.setAttribute('width','240');
  svg.setAttribute('height','160');

  const make = (name, attrs) => {
    const el = document.createElementNS('http://www.w3.org/2000/svg', name);
    for(const [k,v] of Object.entries(attrs)) el.setAttribute(k,String(v));
    return el;
  };

  svg.appendChild(make('path', {
    d:'M120 22c-28 0-42 18-50 40-10 26-6 58 8 78 9 13 22 20 42 20s33-7 42-20c14-20 18-52 8-78-8-22-22-40-50-40z',
    fill:'none', stroke:'white', 'stroke-width':'4', 'stroke-linecap':'round'
  }));

  svg.appendChild(make('path', {
    d:'M48 74c20-16 44-24 72-24s52 8 72 24',
    fill:'none', stroke:'white', 'stroke-width':'4', 'stroke-dasharray':'6 6', 'stroke-linecap':'round'
  }));

  svg.appendChild(make('path', {d:'M60 88l-14-14 20-2z', fill:'white'}));
  svg.appendChild(make('path', {d:'M180 88l14-14-20-2z', fill:'white'}));

  const text = make('text', {
    x:'120', y:'120', 'text-anchor':'middle', fill:'white', 'font-size':'14',
    'font-family':'system-ui, -apple-system, Segoe UI, Roboto, sans-serif'
  });
  text.textContent = t('胸囲を水平に','Keep tape level');
  svg.appendChild(text);

  return svg;
}

function footSvg(){
  const svg = document.createElementNS('http://www.w3.org/2000/svg','svg');
  svg.setAttribute('viewBox','0 0 240 160');
  svg.setAttribute('width','240');
  svg.setAttribute('height','160');

  const make = (name, attrs) => {
    const el = document.createElementNS('http://www.w3.org/2000/svg', name);
    for(const [k,v] of Object.entries(attrs)) el.setAttribute(k,String(v));
    return el;
  };

  svg.appendChild(make('rect', {x:'20', y:'20', width:'14', height:'120', fill:'white'}));
  svg.appendChild(make('line', {x1:'34', y1:'132', x2:'220', y2:'132', stroke:'white', 'stroke-width':'3'}));

  svg.appendChild(make('path', {
    d:'M70 120c-6-20 2-54 18-62 12-6 18 2 26 2 10 0 18-10 28-6 12 6 12 20 22 28 14 12 18 18 14 34-4 14-18 18-46 18-26 0-52-2-62-14z',
    fill:'none', stroke:'white', 'stroke-width':'4', 'stroke-linejoin':'round'
  }));

  svg.appendChild(make('line', {x1:'34', y1:'40', x2:'200', y2:'40', stroke:'white', 'stroke-width':'3', 'stroke-dasharray':'6 6'}));
  svg.appendChild(make('path', {d:'M34 40l10-6v12z', fill:'white'}));
  svg.appendChild(make('path', {d:'M200 40l-10-6v12z', fill:'white'}));

  const text = make('text', {
    x:'120', y:'62', 'text-anchor':'middle', fill:'white', 'font-size':'14',
    'font-family':'system-ui, -apple-system, Segoe UI, Roboto, sans-serif'
  });
  text.textContent = t('壁からつま先まで','Wall → toe');
  svg.appendChild(text);

  return svg;
}

// ---------------- Result actions ----------------
function setResultActionsEnabled(enabled){
  $('copyBtn').disabled = !enabled;
  $('openChartBtn').disabled = !enabled;

  const url = currentItem().productUrl;
  $('productBtn').disabled = !enabled || !url;
  $('productBtn').title = url ? '' : t('商品ページURLが未設定です（app.jsの productUrl に入力してください）。','Product URL is not set (fill productUrl in app.js).');
}

async function copyResultText(){
  const text = $('result').textContent || '';
  if(!text.trim()) return;

  try{
    await navigator.clipboard.writeText(text);
    toast(t('コピーしました','Copied'));
  }catch(e){
    const ta = makeEl('textarea', {style:'position:fixed;left:-9999px;top:-9999px;'}, [text]);
    document.body.appendChild(ta);
    ta.select();
    try{ document.execCommand('copy'); toast(t('コピーしました','Copied')); }catch(_){}
    document.body.removeChild(ta);
  }
}

function openProductPage(){
  const url = currentItem().productUrl;
  if(!url) return;
  window.open(url, '_blank', 'noopener,noreferrer');
}

let toastTimer = null;
function toast(msg){
  const el = $('toast');
  el.textContent = msg;
  el.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.hidden = true; }, 1400);
}

// ---------------- Notes ----------------
function renderNotes(){
  const item = currentItem();
  const lines = [];
  if(lang === 'ja'){
    lines.push('※ 仕上がり寸法は測り方で±1〜2cm程度の差が出る場合があります。');
    lines.push('※ 迷う場合は「ふつう」→ さらにゆったりなら 1サイズ上も検討してください。');
    lines.push('※ 推奨は目安です。最終的にはサイズ表（実寸）をご確認ください。');
    if(item.type === 'shoe'){
      lines.push('※ 足幅が広めの方は、ハーフサイズ上も検討してください（好みによります）。');
    }
  } else {
    lines.push('Note: Finished measurements may vary by about ±1–2 cm.');
    lines.push('Note: If you are between sizes, consider sizing up for a looser fit.');
    lines.push('Note: Recommendations are a guide—please confirm with the size chart.');
    if(item.type === 'shoe'){
      lines.push('Note: If you have wider feet, consider going up half a size (preference-dependent).');
    }
  }
  $('note').textContent = lines.join('\n');
}

// ---------------- Calculation ----------------
function onCalculate(){
  clearFieldErrors();
  const item = currentItem();
  const result = $('result');
  result.hidden = false;

  if(item.type === 'top'){
    const chestRaw = parseFloat(($('chest')||{}).value);
    const heightRaw = parseFloat(($('height')||{}).value);
    const ease = parseFloat(($('fit')||{}).value);

    const v = validateTopInputs(chestRaw, heightRaw);
    if(!v.ok){
      result.textContent = v.message;
      setResultActionsEnabled(false);
      return;
    }

    const rec = pickTopSize(v.chestCm, ease, activeItemId);

    const showChest = (unit === 'cm') ? r1(v.chestCm) : r1(cmToInch(v.chestCm));
    const showTarget = (unit === 'cm') ? r1(rec.target) : r1(cmToInch(rec.target));
    const showGarment = (unit === 'cm') ? r1(rec.garmentChest) : r1(cmToInch(rec.garmentChest));

    let msg = '';
    if(lang === 'ja'){
      msg += '推奨：' + rec.size + '\n';
      msg += 'あなたの胸囲：' + showChest + unit + '\n';
      msg += '目安（胸囲＋ゆとり）：' + showTarget + unit + '\n';
      msg += '推奨サイズの仕上がり胸囲：' + showGarment + unit + '\n';

      if(rec.row && rec.row.lengthCm != null){
        const lenCm = rec.row.lengthCm;
        const showLen = (unit === 'cm') ? r1(lenCm) : r1(cmToInch(lenCm));
        msg += '\n着丈（推奨サイズ）：' + showLen + unit;
        if(v.heightCm){
          msg += '\n目安：' + hemPositionJa(v.heightCm, lenCm);
        }
      }
      if(rec.overflow){
        msg += '\n\n※ 最大サイズでも目安に届きません。実寸を優先して確認してください。';
      }
    } else {
      msg += 'Recommended: ' + rec.size + '\n';
      msg += 'Your chest: ' + showChest + unit + '\n';
      msg += 'Target (chest + ease): ' + showTarget + unit + '\n';
      msg += 'Garment chest (recommended): ' + showGarment + unit + '\n';

      if(rec.row && rec.row.lengthCm != null){
        const lenCm = rec.row.lengthCm;
        const showLen = (unit === 'cm') ? r1(lenCm) : r1(cmToInch(lenCm));
        msg += '\nLength (recommended): ' + showLen + unit;
        if(v.heightCm){
          msg += '\nApprox.: ' + hemPositionEn(v.heightCm, lenCm);
        }
      }
      if(rec.overflow){
        msg += '\n\nNote: Even the largest size may be smaller than target. Please double-check.';
      }
    }

    result.textContent = msg;
    setResultActionsEnabled(true);
    renderNotes();
  } else {
    const footRaw = parseFloat(($('foot')||{}).value);
    const v = validateShoeInputs(footRaw);
    if(!v.ok){
      result.textContent = v.message;
      setResultActionsEnabled(false);
      return;
    }

    const rec = pickShoeSize(v.footCm, activeItemId);

    let msg = '';
    if(unit === 'cm'){
      if(lang === 'ja'){
        msg += '推奨：' + rec.row.sizeJP + '\n';
        msg += 'あなたの足の長さ：' + r1(v.footCm) + 'cm\n';
        msg += 'サイズ表の足の長さ：' + r1(rec.row.footLengthCm) + 'cm\n';
      } else {
        msg += 'Recommended: ' + rec.row.sizeJP + ' (JP)\n';
        msg += 'Your foot length: ' + r1(v.footCm) + 'cm\n';
        msg += 'Chart foot length: ' + r1(rec.row.footLengthCm) + 'cm\n';
      }
    } else {
      const row = rec.row;
      const footIn = r1(cmToInch(v.footCm));
      if(lang === 'ja'){
        msg += '推奨：US ' + row['US'] + ' / UK ' + row['UK'] + ' / EU ' + row['EU'] + '\n';
        msg += 'あなたの足の長さ：' + footIn + 'inch\n';
        msg += 'サイズ表の足の長さ：' + row['leg length'] + 'inch\n';
      } else {
        msg += 'Recommended: US ' + row['US'] + ' / UK ' + row['UK'] + ' / EU ' + row['EU'] + '\n';
        msg += 'Your foot length: ' + footIn + 'inch\n';
        msg += 'Chart foot length: ' + row['leg length'] + 'inch\n';
      }
    }

    if(rec.overflow){
      msg += (lang === 'ja')
        ? '\n\n※ 最大サイズでも足の長さが上回っています。サイズ表の実寸を必ず確認してください。'
        : '\n\nNote: Your measurement exceeds the largest chart size. Please double-check the chart.';
    }

    result.textContent = msg;
    setResultActionsEnabled(true);
    renderNotes();
  }
}

// ---------------- Header text ----------------
function renderHeader(){
  $('unitBtn').textContent = unit;
  $('langBtn').textContent = (lang === 'ja') ? '日本語' : 'English';

  $('subtitle').textContent = t('入力して推奨サイズを表示','Enter measurements for recommendation');
  $('h1').textContent = t('自動サイズ推奨','Size recommendation');
  $('lead').textContent = t('計算はブラウザ内で完結します（入力値は送信されません）。','All calculations run locally in your browser (no data is sent).');

  $('chartBtn').textContent = t('サイズ表','Size chart');
  $('howtoBtn').textContent = t('測り方','How to measure');
  $('calcBtn').textContent = t('推奨サイズを見る','Get recommended size');

  $('copyBtn').textContent = t('結果をコピー','Copy result');
  $('productBtn').textContent = t('この商品ページへ','Go to product page');
  $('openChartBtn').textContent = t('サイズ表を見る','Open size chart');
}

// ---------------- Render all ----------------
function renderAll(){
  renderHeader();
  renderTabs();
  renderForm();
  renderNotes();

  $('result').hidden = true;
  $('result').textContent = '';
  setResultActionsEnabled(false);
}

// ---------------- Events ----------------
function wireEvents(){
  $('unitBtn').addEventListener('click', () => {
    // convert existing input values first (so the number stays visually consistent)
    const item = currentItem();
    if(item.type === 'top'){
      const c = parseFloat(($('chest')||{}).value);
      if(!Number.isNaN(c)) $('chest').value = (unit === 'cm') ? r1(cmToInch(c)) : r1(inchToCm(c));
      const h = parseFloat(($('height')||{}).value);
      if(!Number.isNaN(h)) $('height').value = (unit === 'cm') ? r1(cmToInch(h)) : r1(inchToCm(h));
    } else {
      const f = parseFloat(($('foot')||{}).value);
      if(!Number.isNaN(f)) $('foot').value = (unit === 'cm') ? r1(cmToInch(f)) : r1(inchToCm(f));
    }

    unit = (unit === 'cm') ? 'inch' : 'cm';
    renderAll();
  });

  $('langBtn').addEventListener('click', () => {
    lang = (lang === 'ja') ? 'en' : 'ja';
    renderAll();
  });

  $('calcBtn').addEventListener('click', onCalculate);

  $('chartBtn').addEventListener('click', () => openModal('chart'));
  $('howtoBtn').addEventListener('click', () => openModal('howto'));
  $('openChartBtn').addEventListener('click', () => openModal('chart'));

  $('copyBtn').addEventListener('click', copyResultText);
  $('productBtn').addEventListener('click', openProductPage);

  $('closeBtn').addEventListener('click', closeModal);
  $('modal').addEventListener('click', (e) => {
    const target = e.target;
    if(target && target.dataset && target.dataset.close === '1') closeModal();
  });

  document.addEventListener('keydown', (e) => {
    if(e.key === 'Escape' && !$('modal').hidden) closeModal();
  });
}

wireEvents();
renderAll();
