# TCDA Size Finder (GitHub Pages)

## Files
- index.html
- styles.css
- app.js
- logo.svg (replace with your logo if needed)

## Deploy (GitHub Pages)
1) Upload these files to your repo root
2) Settings → Pages → Deploy from a branch → main / (root)

## Notes
- Works fully offline (no server).
- Unit switch: cm / inch
- Language switch: 日本語 / English
